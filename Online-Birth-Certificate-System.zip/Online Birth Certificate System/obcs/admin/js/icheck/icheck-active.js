(function ($) {
 "use strict";
 
  $('.i-checks').iCheck({
		checkboxClass: 'icheckbox_square-green',
		radioClass: 'iradio_square-green',
	});
	
	
 
})(jQuery); 